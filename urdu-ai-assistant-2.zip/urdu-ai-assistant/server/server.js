// Chota proxy server: API key sirf yahan rehti hai, mobile app mein kabhi nahi.
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.MODEL || 'claude-sonnet-5-5';
const PORT = process.env.PORT || 3000;

const SYSTEM_PROMPT = `Aap ek madadgar AI assistant hain jo Urdu aur Roman Urdu mein baat karta hai.
- Jis zubaan/script mein user likhe (Urdu script ya Roman Urdu), usi mein jawab dein.
- Jawab chhote, saaf aur asaan alfaaz mein dein. Mobile screen ke liye mukhtasar rakhein.
- Agar user English mein likhe to English mein jawab dein.
- Tarjuma, likhai, padhai, aam maloomat aur rozmarra ke sawalon mein madad karein.
- Naram aur izzat bhara lehja rakhein.`;

app.get('/', (_req, res) => res.send('Urdu AI Assistant server chal raha hai ✅'));

app.post('/chat', async (req, res) => {
  try {
    if (!API_KEY) {
      return res.status(500).json({ error: 'Server par ANTHROPIC_API_KEY set nahi hai.' });
    }

    const { messages } = req.body;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages zaroori hain.' });
    }

    // Sirf pichle 20 messages bhejte hain taake kharcha kam rahe
    const trimmed = messages.slice(-20).map((m) => ({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: String(m.content).slice(0, 4000),
    }));

    const apiRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages: trimmed,
      }),
    });

    const data = await apiRes.json();
    if (!apiRes.ok) {
      console.error('API error:', data);
      return res.status(502).json({ error: 'AI service se jawab nahi mila.' });
    }

    const reply = (data.content || [])
      .filter((b) => b.type === 'text')
      .map((b) => b.text)
      .join('\n');

    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server mein masla aa gaya.' });
  }
});

const COMMAND_PROMPT = `Aap ek voice-command parser hain. User Urdu, Roman Urdu ya English mein hukm deta hai.
Sirf ek JSON object wapas dein, aur kuch nahi. Format:
{"action": "...", "params": {...}, "reply": "user ke liye chhota Roman Urdu jawab"}

Mumkin actions:
- "call": params {"number": "+923001234567"} ya {"name": "Ali"}  (number ya contact ka naam, jo user ne bola ho)
- "sms": params {"number": "...", "name": "...", "text": "..."}  (number ya naam)
- "whatsapp": params {"number": "...", "name": "...", "text": "..."}  (number ya naam, dono optional)
- "maps": params {"query": "jagah ka naam"}
- "youtube": params {"query": "..."}
- "web_search": params {"query": "..."}
- "open_app": params {"app": "whatsapp|youtube|maps|settings|camera"}
- "brightness": params {"level": 0.0 se 1.0}
- "chat": params {}  (aam sawal ho to; reply mein poora jawab dein)

Naam ko waisa hi likhein jaisa user ne bola (Roman ya Urdu script). Agar number ya zaroori maloomat kam hon to action "chat" rakhein aur reply mein poochein.`;

app.post('/command', async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: 'ANTHROPIC_API_KEY set nahi hai.' });
    const text = String(req.body.text || '').slice(0, 500);
    if (!text) return res.status(400).json({ error: 'text zaroori hai.' });

    const apiRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 400,
        system: COMMAND_PROMPT,
        messages: [{ role: 'user', content: text }],
      }),
    });
    const data = await apiRes.json();
    if (!apiRes.ok) return res.status(502).json({ error: 'AI service se jawab nahi mila.' });

    const raw = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    const match = raw.match(/\{[\s\S]*\}/);
    let cmd = { action: 'chat', params: {}, reply: raw };
    try { if (match) cmd = JSON.parse(match[0]); } catch (_) {}
    res.json(cmd);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server mein masla aa gaya.' });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`Server port ${PORT} par chal raha hai`));
