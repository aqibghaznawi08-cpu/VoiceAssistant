import React, { useState, useRef } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  StyleSheet,
  StatusBar,
  Linking,
  Alert,
} from 'react-native';
import * as Speech from 'expo-speech';
import * as Brightness from 'expo-brightness';
import * as Contacts from 'expo-contacts';
import {
  ExpoSpeechRecognitionModule,
  useSpeechRecognitionEvent,
} from 'expo-speech-recognition';

// ⚠️ Yahan apne server ka address likhein (README dekhein).
const SERVER_URL = 'http://192.168.1.10:3000';

const WELCOME = {
  id: 'welcome',
  role: 'assistant',
  content:
    'Assalam-o-Alaikum! 👋 Mic dabakar bolein, jaise: "Ali ko call karo +923001234567", "YouTube par naat lagao", "brightness kam karo".',
};

// Contact ka naam se number dhoondta hai. Naam na mile ya ijazat na ho to null.
async function findNumber(name) {
  const { status } = await Contacts.requestPermissionsAsync();
  if (status !== 'granted') {
    Alert.alert('Ijazat chahiye', 'Contacts ki ijazat dein taake main naam se number dhoond sakun.');
    return null;
  }
  const { data } = await Contacts.getContactsAsync({
    name,
    fields: [Contacts.Fields.PhoneNumbers],
  });
  const match = data.find((c) => c.phoneNumbers && c.phoneNumbers.length);
  if (!match) {
    Alert.alert('Nahi mila', `"${name}" naam ka koi number contacts mein nahi mila.`);
    return null;
  }
  return match.phoneNumbers[0].number;
}

// Voice command ko asal phone action mein badalta hai
async function runAction(cmd) {
  const p = { ...(cmd.params || {}) };
  const enc = encodeURIComponent;
  try {
    if (['call', 'sms', 'whatsapp'].includes(cmd.action) && !p.number && p.name) {
      p.number = await findNumber(p.name);
      if (!p.number) return;
    }
    switch (cmd.action) {
      case 'call':
        if (p.number) await Linking.openURL(`tel:${p.number}`);
        break;
      case 'sms':
        await Linking.openURL(`sms:${p.number || ''}${p.text ? `?body=${enc(p.text)}` : ''}`);
        break;
      case 'whatsapp': {
        const num = (p.number || '').replace(/[^\d]/g, '');
        await Linking.openURL(
          `https://wa.me/${num}${p.text ? `?text=${enc(p.text)}` : ''}`
        );
        break;
      }
      case 'maps':
        await Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${enc(p.query || '')}`);
        break;
      case 'youtube':
        await Linking.openURL(`https://www.youtube.com/results?search_query=${enc(p.query || '')}`);
        break;
      case 'web_search':
        await Linking.openURL(`https://www.google.com/search?q=${enc(p.query || '')}`);
        break;
      case 'open_app': {
        const apps = {
          whatsapp: 'whatsapp://',
          youtube: 'vnd.youtube://',
          maps: 'https://maps.google.com',
        };
        if (p.app === 'settings') await Linking.openSettings();
        else if (apps[p.app]) await Linking.openURL(apps[p.app]);
        break;
      }
      case 'brightness': {
        const { status } = await Brightness.requestPermissionsAsync();
        if (status === 'granted') {
          const level = Math.max(0.05, Math.min(1, Number(p.level) || 0.5));
          await Brightness.setBrightnessAsync(level);
        }
        break;
      }
      default:
        break;
    }
  } catch (e) {
    Alert.alert('Maazrat', 'Yeh kaam is phone par nahi ho saka.');
  }
}

export default function App() {
  const [messages, setMessages] = useState([WELCOME]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const [heard, setHeard] = useState('');
  const listRef = useRef(null);

  const scrollToEnd = () =>
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);

  const addMsg = (role, content, extra = {}) =>
    setMessages((prev) => [...prev, { id: String(Date.now() + Math.random()), role, content, ...extra }]);

  // ---- Voice command ----
  const handleVoice = async (text) => {
    addMsg('user', `🎤 ${text}`);
    setLoading(true);
    try {
      const res = await fetch(`${SERVER_URL}/command`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      const cmd = await res.json();
      if (!res.ok) throw new Error(cmd.error);
      addMsg('assistant', cmd.reply || 'Theek hai.');
      Speech.speak(cmd.reply || 'Theek hai', { language: 'ur-PK' });
      await runAction(cmd);
    } catch (e) {
      addMsg('assistant', 'Maazrat, kuch masla aa gaya. Internet ya server check karein.', { error: true });
    } finally {
      setLoading(false);
      scrollToEnd();
    }
  };

  useSpeechRecognitionEvent('start', () => setListening(true));
  useSpeechRecognitionEvent('end', () => setListening(false));
  useSpeechRecognitionEvent('error', () => {
    setListening(false);
    setHeard('');
  });
  useSpeechRecognitionEvent('result', (event) => {
    const t = event.results?.[0]?.transcript || '';
    setHeard(t);
    if (event.isFinal && t) {
      setHeard('');
      handleVoice(t);
    }
  });

  const toggleMic = async () => {
    if (listening) {
      ExpoSpeechRecognitionModule.stop();
      return;
    }
    const perm = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Ijazat chahiye', 'Mic ki ijazat dein taake main aap ki awaaz sun sakun.');
      return;
    }
    Speech.stop();
    ExpoSpeechRecognitionModule.start({ lang: 'ur-PK', interimResults: true });
  };

  // ---- Text chat ----
  const sendMessage = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const userMsg = { id: String(Date.now()), role: 'user', content: text };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setInput('');
    setLoading(true);
    scrollToEnd();

    try {
      const history = updated
        .filter((m) => m.id !== 'welcome' && !m.error)
        .map(({ role, content }) => ({ role, content: content.replace(/^🎤 /, '') }));

      const res = await fetch(`${SERVER_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: history }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Server error');
      addMsg('assistant', data.reply);
    } catch (err) {
      addMsg('assistant', 'Maazrat, kuch masla aa gaya. Internet ya server check karein.', { error: true });
    } finally {
      setLoading(false);
      scrollToEnd();
    }
  };

  const clearChat = () => {
    Speech.stop();
    setMessages([WELCOME]);
  };

  const renderItem = ({ item }) => {
    const isUser = item.role === 'user';
    return (
      <View
        style={[
          styles.bubble,
          isUser ? styles.userBubble : styles.botBubble,
          item.error && styles.errorBubble,
        ]}
      >
        <Text style={[styles.msgText, isUser && styles.userText]}>{item.content}</Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0f766e" />

      <View style={styles.header}>
        <Text style={styles.title}>Urdu AI Assistant</Text>
        <TouchableOpacity onPress={clearChat}>
          <Text style={styles.clear}>Naya chat</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          onContentSizeChange={scrollToEnd}
        />

        {(loading || listening) && (
          <View style={styles.typing}>
            {loading ? <ActivityIndicator size="small" color="#0f766e" /> : null}
            <Text style={styles.typingText}>
              {listening ? `🎙️ Sun raha hoon... ${heard}` : '  Soch raha hoon...'}
            </Text>
          </View>
        )}

        <View style={styles.inputRow}>
          <TouchableOpacity
            style={[styles.micBtn, listening && styles.micActive]}
            onPress={toggleMic}
          >
            <Text style={styles.micText}>{listening ? '⏹' : '🎤'}</Text>
          </TouchableOpacity>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder="Likhein ya mic dabayein..."
            placeholderTextColor="#94a3b8"
            multiline
          />
          <TouchableOpacity
            style={[styles.sendBtn, (!input.trim() || loading) && { opacity: 0.5 }]}
            onPress={sendMessage}
            disabled={!input.trim() || loading}
          >
            <Text style={styles.sendText}>Bhejein</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f1f5f9' },
  header: {
    backgroundColor: '#0f766e',
    paddingHorizontal: 16,
    paddingVertical: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: { color: '#fff', fontSize: 18, fontWeight: '700' },
  clear: { color: '#ccfbf1', fontSize: 14 },
  list: { padding: 12 },
  bubble: { maxWidth: '82%', padding: 12, borderRadius: 16, marginVertical: 5 },
  userBubble: { alignSelf: 'flex-end', backgroundColor: '#0f766e', borderBottomRightRadius: 4 },
  botBubble: { alignSelf: 'flex-start', backgroundColor: '#fff', borderBottomLeftRadius: 4 },
  errorBubble: { backgroundColor: '#fee2e2' },
  msgText: { fontSize: 16, lineHeight: 23, color: '#0f172a' },
  userText: { color: '#fff' },
  typing: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 6 },
  typingText: { color: '#475569', fontSize: 13 },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 10,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  micBtn: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#ccfbf1',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  micActive: { backgroundColor: '#fecaca' },
  micText: { fontSize: 22 },
  input: {
    flex: 1,
    maxHeight: 120,
    backgroundColor: '#f1f5f9',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 16,
    color: '#0f172a',
  },
  sendBtn: {
    marginLeft: 8,
    backgroundColor: '#0f766e',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
  },
  sendText: { color: '#fff', fontWeight: '700' },
});
