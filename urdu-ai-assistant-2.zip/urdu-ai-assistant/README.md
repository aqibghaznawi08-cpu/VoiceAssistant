# Urdu AI Assistant (Mobile App)

Android aur iOS dono par chalne wali Urdu / Roman Urdu AI chat app.

```
urdu-ai-assistant/
├── app/      -> Mobile app (Expo / React Native)
└── server/   -> Chota server (API key yahan mehfooz rehti hai)
```

## Zaroori cheezein
- Node.js 18 ya naya (nodejs.org)
- Android phone (USB debugging on) ya emulator. Awaaz wali feature **Expo Go mein nahi chalti**, custom build chahiye.
- Anthropic API key (console.anthropic.com se)

## Step 1: Server chalayein
```bash
cd server
npm install
cp .env.example .env      # phir .env kholkar apni API key likhein
npm start
```
Browser mein `http://localhost:3000` kholein, "chal raha hai" likha aana chahiye.

## Step 2: App mein server ka address likhein
`app/App.js` mein `SERVER_URL` badlein:
- Asli phone (same WiFi): `http://<computer-ka-IP>:3000`
  (Windows: `ipconfig`, Mac/Linux: `ifconfig` se IP milega)
- Android emulator: `http://10.0.2.2:3000`

## Step 3: App chalayein
```bash
cd app
npm install
npx expo run:android     # phone USB se jura ho, pehli build mein kuch minute lagte hain
```
Pehli dafa mic aur brightness ki ijazat mangi jayegi. (iPhone ke liye `npx expo run:ios`, Mac aur Xcode chahiye.)

## Awaaz se kya kya hota hai
Mic dabakar bolein, jaise:
- "Ali ko call karo" (contacts se naam dhoond kar) ya "+923001234567 par call karo"
- "Is number par SMS bhejo ... ki main late hoon"
- "WhatsApp par hello bhejo"
- "Lahore ka Badshahi Masjid maps mein dikhao"
- "YouTube par naat lagao"
- "Brightness kam karo"

**Hadood:** app sirf apne andar ke kaam karti hai. Wifi/Bluetooth on-off, doosri apps ke andar click karna, ya poora phone control karna aam app se Android/iOS allow nahi karte. Naam se call/SMS/WhatsApp ke liye contacts ki ijazat deni hogi. Agar ek naam ke kai contacts hon to pehla number istemal hota hai.

## Aage kya karein
- **Internet par rakhein**: server ko Render, Railway ya Fly.io par deploy karein, phir `SERVER_URL` ko uske https address se badlein.
- **APK/IPA banayein**: `npx eas-cli build -p android` (Play Store ke liye).
- **Aur features**: awaaz se sawal (voice), chat history save karna, Urdu (Nastaliq) font, dark mode.

## Ahem baat
API key kabhi `app/` ke andar na rakhein. Woh sirf `server/.env` mein rahe, warna koi bhi app se nikal kar istemal kar sakta hai.
